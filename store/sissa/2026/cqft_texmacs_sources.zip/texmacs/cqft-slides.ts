<TeXmacs|2.1.4>

<style|source>

<\body>
  <\active*>
    <\src-title>
      <src-package|cqft-slides|2.0>

      <src-purpose|Presentation macros of the SISSA lecture slides and their
      HTML export, on top of the package max-html-slides of the max-html
      plugin.>

      <src-copyright|2026|Massimiliano Gubinelli>
    </src-title>
  </active*>

  <use-package|max-html-slides>

  <\active*>
    <\src-comment>
      Macros of the presentation style of talk-stochastic-observables-2026.tm
      (kept here, not in the document preambles, so that their HTML
      renderings below are used on export).
    </src-comment>
  </active*>

  <assign|font|mathlarge=TeX Gyre Pagella,cal=TeX Gyre Termes, bold-cal=TeX
  Gyre Termes,frak=TeX Gyre Pagella,bbb=TeX Gyre Pagella,math=TeX Gyre
  Pagella,Avenir>

  <assign|triang|<math|\<vartriangleright\><space|0.8spc>>>

  <assign|hand|<shift|<large|\<#261E\>>||-0.1em>>

  <assign|mynote|<macro|body|<very-small|<with|color|dark
  grey|[<arg|body>]>>>>

  <assign|myframed|<\macro|body>
    <\wide-tabular>
      <tformat|<cwith|1|1|1|1|cell-tborder|0.5ln>|<cwith|1|1|1|1|cell-bborder|0.5ln>|<cwith|1|1|1|1|cell-lborder|0ln>|<cwith|1|1|1|1|cell-rborder|0ln>|<cwith|1|1|1|1|cell-halign|c>|<cwith|1|1|1|1|cell-lsep|0.3em>|<cwith|1|1|1|1|cell-rsep|0.3em>|<cwith|1|1|1|1|cell-bsep|0.3em>|<cwith|1|1|1|1|cell-tsep|0.3em>|<table|<row|<\cell>
        <arg|body>
      </cell>>>>
    </wide-tabular>
  </macro>>

  <assign|myframed-2|<\macro|body>
    <\framed>
      <\wide-tabular>
        <tformat|<cwith|1|1|1|1|cell-lsep|0.3em>|<cwith|1|1|1|1|cell-rsep|0.3em>|<cwith|1|1|1|1|cell-bsep|0.3em>|<cwith|1|1|1|1|cell-tsep|0.3em>|<table|<row|<\cell>
          <arg|body>
        </cell>>>>
      </wide-tabular>
    </framed>
  </macro>>

  <assign|mytitle|<\macro|tit>
    <\with|color|dark red>
      <\wide-tabular>
        <tformat|<cwith|1|1|1|1|cell-lsep|0.5em>|<cwith|1|1|1|1|cell-rsep|0.5em>|<cwith|1|1|1|1|cell-bsep|0.5em>|<cwith|1|1|1|1|cell-tsep|0.5em>|<cwith|1|1|1|1|cell-tborder|0ln>|<cwith|1|1|1|1|cell-bborder|0ln>|<cwith|1|1|1|1|cell-lborder|1ln>|<cwith|1|1|1|1|cell-rborder|0ln>|<table|<row|<\cell>
          <with|font-series|bold|<arg|tit>>
        </cell>>>>
      </wide-tabular>
    </with>
  </macro>>

  <\active*>
    <\src-comment>
      Theorem-like environments (theorems, propositions, lemmas,
      corollaries, definitions) are boxed with myframed-2; on export the
      box becomes a block of class slide-box.
    </src-comment>
  </active*>

  <assign|cqft-render-theorem|<value|render-theorem>>

  <assign|render-theorem|<\macro|which|body>
    <\myframed-2>
      <cqft-render-theorem|<arg|which>|<arg|body>>
    </myframed-2>
  </macro>>

  <assign|mydot|<math|\<cdot\>>>

  <\active*>
    <\src-comment>
      Titles: the course title and the lecture title on the title slide, and
      the titles of the slides that open each part of a lecture. Tune the
      sizes here.
    </src-comment>
  </active*>

  <assign|cqft-course-name|<macro|A Constructive Introduction to Quantum Field Theory>>

  <assign|cqft-author|<macro|Massimiliano Gubinelli \| University of Oxford>>

  <assign|cqft-course-title|<macro|body|<with|font-size|1.25|font-series|bold|color|dark
  red|<arg|body>>>>

  <assign|cqft-lecture-title|<macro|body|<with|font-size|1.15|<arg|body>>>>

  <\active*>
    <\src-comment>
      The title slide of each lecture: cqft-title-slide|lecture title|credit
      line (may be empty)|information line. The course name (on one line)
      and the author are cqft-course-name and cqft-author; the spacing is
      set here.
    </src-comment>
  </active*>

  <assign|cqft-title-slide|<\macro|title|credit|info>
    <\with|par-mode|left>
      <vspace*|1.2cm>

      <cqft-course-title|<cqft-course-name>>

      <vspace|0.3cm>

      <cqft-lecture-title|<arg|title>>

      <vspace|1.2cm>

      <small|<cqft-author>>

      <small|<if|<unequal|<arg|credit>|>|<arg|credit><next-line>><with|color|dark
      grey|<arg|info>>>
    </with>
  </macro>>

  <assign|cqft-part-title|<macro|body|<with|font-size|1.35|font-series|bold|color|dark
  red|<arg|body>>>>

  <\active*>
    <\src-comment>
      Text tables: data-table (natural width) and wide-data-table (full
      width) take a tformat whose table has a header row; rules above and
      below the header and below the last row, cells centred vertically,
      padding data-table-hsep and data-table-vsep, rule width
      data-table-rule. Extra cwith's in the argument are kept.
    </src-comment>
  </active*>

  <assign|data-table-hsep|0.6em>

  <assign|data-table-vsep|0.25fn>

  <assign|data-table-rule|1ln>

  <assign|data-table|<macro|body|<tabular*|<tformat|<cwith|1|-1|1|-1|cell-valign|c>|<cwith|1|-1|1|-1|cell-lsep|<value|data-table-hsep>>|<cwith|1|-1|1|-1|cell-rsep|<value|data-table-hsep>>|<cwith|1|-1|1|-1|cell-tsep|<value|data-table-vsep>>|<cwith|1|-1|1|-1|cell-bsep|<value|data-table-vsep>>|<cwith|1|1|1|-1|cell-tborder|<value|data-table-rule>>|<cwith|1|1|1|-1|cell-bborder|<value|data-table-rule>>|<cwith|-1|-1|1|-1|cell-bborder|<value|data-table-rule>>|<arg|body>>>>>

  <assign|wide-data-table|<macro|body|<wide-tabular|<tformat|<cwith|1|-1|1|-1|cell-valign|c>|<cwith|1|-1|1|-1|cell-lsep|<value|data-table-hsep>>|<cwith|1|-1|1|-1|cell-rsep|<value|data-table-hsep>>|<cwith|1|-1|1|-1|cell-tsep|<value|data-table-vsep>>|<cwith|1|-1|1|-1|cell-bsep|<value|data-table-vsep>>|<cwith|1|1|1|-1|cell-tborder|<value|data-table-rule>>|<cwith|1|1|1|-1|cell-bborder|<value|data-table-rule>>|<cwith|-1|-1|1|-1|cell-bborder|<value|data-table-rule>>|<arg|body>>>>>

  <\active*>
    <\src-comment>
      Stylesheets and the slide viewer of max-html-slides (from the plugin's
      resources folder), the fonts and cqft-slides.css, next to the HTML
      pages. max-html-slides also gives HTML renderings of mytitle,
      myframed and myframed-2.
    </src-comment>
  </active*>

  <assign|html-extra-css|<tuple|max-html-slides.css|https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,400;0,600;1,400&display=swap|cqft-slides.css|/resources/course-materials.css>>

  <assign|html-extra-javascript-src|<tuple|max-html-slides.js>>

  <assign|html-head-favicon|cqft-icon.svg>
</body>

<\initial>
  <\collection>
    <associate|preamble|true>
  </collection>
</initial>
